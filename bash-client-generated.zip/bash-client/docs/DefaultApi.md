# DefaultApi

All URIs are relative to **

Method | HTTP request | Description
------------- | ------------- | -------------
[**chat**](DefaultApi.md#chat) | **POST** /api/chat | Generate a response from a model given a chat history
[**copyModel**](DefaultApi.md#copyModel) | **POST** /api/copy | Copy a model
[**createModel**](DefaultApi.md#createModel) | **POST** /api/create | Create a model from a Modelfile
[**deleteModel**](DefaultApi.md#deleteModel) | **DELETE** /api/delete | Delete a model
[**embeddings**](DefaultApi.md#embeddings) | **POST** /api/embeddings | Generate embeddings for a prompt with a model
[**generate**](DefaultApi.md#generate) | **POST** /api/generate | Generate a completion for a prompt with a model
[**heartbeat**](DefaultApi.md#heartbeat) | **GET** /api/heartbeat | Check if server is running
[**listModels**](DefaultApi.md#listModels) | **POST** /api/list | List models in the library
[**pullModel**](DefaultApi.md#pullModel) | **POST** /api/pull | Pull a model from a registry
[**pushModel**](DefaultApi.md#pushModel) | **POST** /api/push | Push a model to a registry
[**showModel**](DefaultApi.md#showModel) | **POST** /api/show | Show model information


## **chat**

Generate a response from a model given a chat history

Generate a chat completion for the given chat history with the specified model

### Example
```bash
 chat
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **copyModel**

Copy a model

Create a copy of a model

### Example
```bash
 copyModel
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **createModel**

Create a model from a Modelfile

Create a model from a Modelfile

### Example
```bash
 createModel
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **deleteModel**

Delete a model

Remove a model from the library

### Example
```bash
 deleteModel
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **embeddings**

Generate embeddings for a prompt with a model

Generate embeddings for the given prompt with the specified model

### Example
```bash
 embeddings
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **generate**

Generate a completion for a prompt with a model

Generate a response for a given prompt with the specified model

### Example
```bash
 generate
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **heartbeat**

Check if server is running

Returns a heartbeat response if the server is running

### Example
```bash
 heartbeat
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **listModels**

List models in the library

List all models that are available locally

### Example
```bash
 listModels
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **pullModel**

Pull a model from a registry

Download a model from a registry to the local library

### Example
```bash
 pullModel
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **pushModel**

Push a model to a registry

Upload a model from the library to a registry

### Example
```bash
 pushModel
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **showModel**

Show model information

Show details about a model

### Example
```bash
 showModel
```

### Parameters
This endpoint does not need any parameter.

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: Not Applicable

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

